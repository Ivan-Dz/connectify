"""Connectify - minimal package init
"""
from .weather import OpenWeather

__all__ = ["OpenWeather"]

# package metadata
__version__ = "0.1.0"